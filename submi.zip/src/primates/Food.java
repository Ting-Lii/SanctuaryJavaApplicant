package primates;

/**
 * This is the enum class of primates' favorite food.
 */
public enum Food {
    EGGS, FRUITS, INSECTS,
    LEAVES, NUTS,
    SEEDS, TREE_SAP

    }

package primates;

/**
 * This is the all the types of the primates in the sanctuary.
 */
public enum Species {
    DRILL,
    GUEREZA,
    HOWLER,
    MANGABEY,
    SAKI,
    SPIDER,
    SQUIRREL,
    TAMARIN
}

package primates;

/**
 * This is the enum class of primates' sex.
 */

public enum Sex {
    FEMALE, MALE, UNCERTAIN
}
